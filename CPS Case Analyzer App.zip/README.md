
  # CPS Case Analyzer App

  This is a code bundle for CPS Case Analyzer App. The original project is available at https://www.figma.com/design/418X8aWcomzDv6WZoEC0LG/CPS-Case-Analyzer-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  