# 🚀 DEPLOY CPS PUNISHER TO GITHUB + VERCEL

## ✅ YOU'RE READY TO DEPLOY!

All configuration files are created. Follow these commands exactly.

---

## 📋 STEP 1: OPEN TERMINAL

**Windows:**
1. Press Windows Key
2. Type: `cmd`
3. Press Enter

**Mac:**
1. Press Cmd + Space
2. Type: `terminal`
3. Press Enter

---

## 📂 STEP 2: NAVIGATE TO YOUR PROJECT FOLDER

You need to download this code first. But since you're in Figma Make, we'll use GitHub directly.

---

## 🔑 STEP 3: SET UP GIT (ONE TIME ONLY)

Copy and paste these commands ONE AT A TIME:

```bash
git config --global user.name "DARREN GUAY"
```

Press Enter, then:

```bash
git config --global user.email "your-email@example.com"
```

**⚠️ IMPORTANT:** Replace `your-email@example.com` with your real email!

---

## 🌐 STEP 4: CREATE GITHUB REPOSITORY

1. Go to: https://github.com/new
2. Sign in as: **FIGHTCPS2023**
3. Repository name: `cps-punisher`
4. Description: "CPS Case Defense Analyzer"
5. Set to: **Private** (recommended) or Public
6. **DO NOT** check "Add README" or ".gitignore" (we already have them!)
7. Click: **Create repository**

---

## 📤 STEP 5: YOU HAVE 2 OPTIONS

### **OPTION A: Deploy from Figma Make Directly** ⭐ RECOMMENDED

Since you're in Figma Make, you can't run git commands directly here.

**Instead, we'll use Vercel's GitHub integration:**

1. Download all files from Figma Make (if there's an export option)
2. Or use Vercel's direct deployment

### **OPTION B: I'll help you set up GitHub CLI or web upload**

---

## 🎯 NEXT: DEPLOY TO VERCEL

Once code is on GitHub:

1. Go to: https://vercel.com/new
2. Sign in with GitHub (FIGHTCPS2023)
3. Import repository: `cps-punisher`
4. Click: **Deploy**
5. Wait 2-3 minutes
6. ✅ DEPLOYED!

---

## 🌐 CONNECT YOUR DOMAIN

1. In Vercel → Project → Settings → Domains
2. Add: `cpspunisher.com`
3. Copy DNS records
4. Add to Namecheap Advanced DNS
5. Wait 15-30 minutes
6. ✅ LIVE at cpspunisher.com!

---

## 🆘 NEED HELP?

Ask for step-by-step guidance!
