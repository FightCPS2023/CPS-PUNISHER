import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Card } from "./ui/card";
import { Plus, Calendar } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "./ui/tooltip";
import { HelpTooltip, InfoBox } from "./ui/help-tooltip";

interface TimelineEvent {
  id: string;
  date: string;
  title: string;
  description: string;
}

interface CaseTimelineProps {
  events: TimelineEvent[];
  onAddEvent: (event: Omit<TimelineEvent, "id">) => void;
}

export function CaseTimeline({ events, onAddEvent }: CaseTimelineProps) {
  const [newEvent, setNewEvent] = useState({
    date: "",
    title: "",
    description: "",
  });
  const [showForm, setShowForm] = useState(false);

  const handleSubmit = () => {
    if (newEvent.date && newEvent.title) {
      onAddEvent(newEvent);
      setNewEvent({ date: "", title: "", description: "" });
      setShowForm(false);
    }
  };

  const sortedEvents = [...events].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
          <h2 className="text-base sm:text-lg">Case Timeline</h2>
          <HelpTooltip 
            content="Document every important event in your case chronologically. This creates a clear picture of what happened and when, which is crucial for identifying procedural violations and building your defense." 
            side="right"
          />
        </div>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button onClick={() => setShowForm(!showForm)} variant="outline" size="sm" className="w-full sm:w-auto">
              <Plus className="w-4 h-4 mr-2" />
              Add Event
            </Button>
          </TooltipTrigger>
          <TooltipContent>Add a new event to your case timeline</TooltipContent>
        </Tooltip>
      </div>

      {events.length === 0 && !showForm && (
        <InfoBox title="Why Timeline Matters" variant="primary">
          <p className="mb-3">A detailed timeline is one of your most powerful defense tools:</p>
          <ul className="space-y-2 list-disc list-inside">
            <li><strong>Exposes Procedural Violations:</strong> Shows missed deadlines and improper procedures</li>
            <li><strong>Reveals Inconsistencies:</strong> Highlights contradictions in CPS statements</li>
            <li><strong>Proves Your Case:</strong> Documents your cooperation and efforts</li>
            <li><strong>Court Presentation:</strong> Provides clear, organized evidence for hearings</li>
            <li><strong>Memory Aid:</strong> Helps you remember details months or years later</li>
          </ul>
          <p className="mt-3 text-xs italic">💡 Tip: Add events as they happen - don't wait. Include dates of visits, phone calls, court hearings, and any significant interactions with CPS.</p>
        </InfoBox>
      )}

      {showForm && (
        <Card className="p-3 sm:p-4 space-y-3 sm:space-y-4">
          <div className="space-y-2">
            <Label htmlFor="eventDate" className="text-sm">Date</Label>
            <Input
              id="eventDate"
              type="date"
              value={newEvent.date}
              onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
              className="h-9 sm:h-10 text-sm"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="eventTitle" className="text-sm">Event Title</Label>
            <Input
              id="eventTitle"
              value={newEvent.title}
              onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
              placeholder="e.g., Initial home visit"
              className="h-9 sm:h-10 text-sm"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="eventDescription" className="text-sm">Description</Label>
            <Textarea
              id="eventDescription"
              value={newEvent.description}
              onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
              placeholder="Event details..."
              rows={3}
              className="text-sm"
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button onClick={handleSubmit} className="w-full sm:w-auto" size="sm">Add Event</Button>
            <Button variant="outline" onClick={() => setShowForm(false)} className="w-full sm:w-auto" size="sm">Cancel</Button>
          </div>
        </Card>
      )}

      <div className="space-y-3 sm:space-y-4">
        {sortedEvents.length === 0 ? (
          <p className="text-center py-6 sm:py-8 text-xs sm:text-sm text-muted-foreground">No timeline events yet. Add an event to get started.</p>
        ) : (
          sortedEvents.map((event, index) => (
            <div key={event.id} className="flex gap-2 sm:gap-4">
              <div className="flex flex-col items-center flex-shrink-0">
                <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-primary" />
                {index < sortedEvents.length - 1 && (
                  <div className="w-0.5 h-full min-h-[50px] sm:min-h-[60px] bg-border" />
                )}
              </div>
              <Card className="flex-1 p-3 sm:p-4 mb-3 sm:mb-4 min-w-0">
                <div className="flex justify-between items-start mb-1 sm:mb-2">
                  <div className="flex-1 min-w-0">
                    <div className="text-xs sm:text-sm text-muted-foreground">
                      {new Date(event.date).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </div>
                  </div>
                </div>
                <div className="text-sm sm:text-base font-medium mb-1">{event.title}</div>
                {event.description && (
                  <p className="text-xs sm:text-sm text-muted-foreground break-words">{event.description}</p>
                )}
              </Card>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
