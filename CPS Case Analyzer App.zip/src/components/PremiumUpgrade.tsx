import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Crown, Check, X, Lock, Shield, FileText, Brain, 
  Calendar, FileCheck, Database, FolderOpen, Mic, 
  Bell, Zap, ArrowRight, Sparkles, Star
} from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { useSubscription } from '../contexts/SubscriptionContext';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

interface PremiumUpgradeProps {
  isOpen?: boolean;
  onClose?: () => void;
  feature?: string; // Which feature triggered the upgrade prompt
}

export function PremiumUpgrade({ isOpen = false, onClose, feature }: PremiumUpgradeProps) {
  const { tier, setTier } = useSubscription();
  const [showModal, setShowModal] = useState(isOpen);
  const [selectedTier, setSelectedTier] = useState<'premium' | 'attorney'>('premium');

  const handleUpgrade = (newTier: 'premium' | 'attorney') => {
    setTier(newTier);
    if (onClose) onClose();
    setShowModal(false);
  };

  const premiumFeatures = [
    {
      icon: FileText,
      title: 'Advanced Document Generator',
      description: 'AI auto-fills custom affidavits, FOIA requests, motion templates, CPS violation notices, and court filings with your case details',
      free: '5 basic templates',
      premium: 'Unlimited auto-filled documents',
      highlight: true
    },
    {
      icon: Brain,
      title: 'Unlimited AI Analysis',
      description: 'Upload court orders, case plans, emails, safety plans - AI finds violations, due process issues, conflicts of interest, fraud indicators, illegal entries',
      free: '3 document uploads',
      premium: 'Unlimited uploads & deep AI analysis',
      highlight: true
    },
    {
      icon: Calendar,
      title: 'Unlimited Timeline Generator',
      description: 'Add photos, audio, video, child statements with automatic date detection, PDF export, attorney-ready formatting',
      free: '1 timeline, text export only',
      premium: 'Unlimited timelines with media & PDF export',
      highlight: false
    },
    {
      icon: FileCheck,
      title: 'Full Violation Report + Case Summary',
      description: 'AI generates professional brief with all violations, statutes, case law, constitutional issues, missing evidence, and next steps',
      free: '2 violations, summary only',
      premium: 'Complete violation analysis with legal brief',
      highlight: true
    },
    {
      icon: Database,
      title: 'Secure Encrypted Storage',
      description: 'Military-grade encryption for all documents, evidence, photos, audio, and CPS reports',
      free: 'Local storage only',
      premium: 'Encrypted cloud storage',
      highlight: false
    },
    {
      icon: FolderOpen,
      title: 'Virtual Case Binder',
      description: 'Professional case organization with sections for everything, drag-and-drop filing, auto-classified uploads',
      free: 'Basic document list',
      premium: 'Full case management system',
      highlight: false
    },
    {
      icon: Mic,
      title: 'Unlimited Podcast Conversions',
      description: 'Multiple expert voices, remove identifying info for privacy, create case update series',
      free: '1 podcast/month',
      premium: 'Unlimited podcasts with privacy controls',
      highlight: true
    },
    {
      icon: Bell,
      title: 'Real-Time Notifications',
      description: 'Proactive alerts when violations detected, illegal safety plans identified, or critical actions needed',
      free: 'None',
      premium: 'Smart notifications & action alerts',
      highlight: false
    },
    {
      icon: Zap,
      title: 'Priority AI Support',
      description: 'Unlimited daily AI legal Q&A instead of 3 questions/day',
      free: '3 questions/day',
      premium: 'Unlimited AI legal assistance',
      highlight: false
    }
  ];

  const comparisonFeatures = [
    { feature: 'Document Uploads', free: '3 uploads', premium: 'Unlimited' },
    { feature: 'Document Generation', free: '5 basic templates', premium: 'Unlimited auto-filled' },
    { feature: 'AI Analysis', free: 'Basic', premium: 'Deep analysis + fraud detection' },
    { feature: 'Violation Analysis', free: '2 violations (summary)', premium: 'Unlimited (full case law)' },
    { feature: 'Timeline', free: '1 timeline, text export', premium: 'Unlimited + media + PDF' },
    { feature: 'Podcast', free: '1/month', premium: 'Unlimited + privacy controls' },
    { feature: 'Evidence Storage', free: '5 entries, 1 photo, 1 audio', premium: 'Unlimited encrypted storage' },
    { feature: 'AI Questions', free: '3/day', premium: 'Unlimited' },
    { feature: 'Case Binder', free: 'Basic list', premium: 'Professional organization' },
    { feature: 'Notifications', free: 'None', premium: 'Real-time alerts' },
    { feature: 'Legal Brief', free: 'None', premium: 'AI-generated professional brief' },
    { feature: 'State-Specific', free: 'Generic guidance', premium: 'Customized for your state' }
  ];

  if (tier === 'premium') {
    return (
      <Alert className="bg-gradient-to-r from-amber-50 to-yellow-50 border-amber-200">
        <Crown className="h-4 w-4 text-amber-600" />
        <AlertTitle className="text-amber-900">Premium Member</AlertTitle>
        <AlertDescription className="text-amber-800">
          You have full access to all premium features. Thank you for supporting CPS Case Defense Analyzer!
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <>
      <Dialog open={showModal || isOpen} onOpenChange={(open) => {
        setShowModal(open);
        if (!open && onClose) onClose();
      }}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center gap-2 mb-2">
              <Crown className="w-6 h-6 text-amber-500" />
              <DialogTitle className="text-2xl">Upgrade to Premium</DialogTitle>
              <Badge className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white">
                $19.99/month
              </Badge>
            </div>
            <DialogDescription>
              {feature ? (
                <span className="text-base">
                  <strong className="text-amber-600">{feature}</strong> is a premium feature. 
                  Unlock this and all other premium features for just $19.99/month.
                </span>
              ) : (
                <span className="text-base">
                  Transform your CPS defense with unlimited AI analysis, professional document generation, 
                  and a complete legal powerhouse toolkit.
                </span>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 mt-6">
            {/* Highlighted Benefits */}
            <div className="grid md:grid-cols-2 gap-4">
              {premiumFeatures.filter(f => f.highlight).map((item, idx) => (
                <Card key={idx} className="p-4 border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-yellow-50">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="mb-1 text-amber-900 flex items-center gap-2">
                        {item.title}
                        <Sparkles className="w-4 h-4 text-amber-500" />
                      </div>
                      <p className="text-sm text-amber-800 mb-2">{item.description}</p>
                      <div className="flex items-center gap-2 text-xs">
                        <Badge variant="outline" className="bg-white">Free: {item.free}</Badge>
                        <ArrowRight className="w-3 h-3 text-amber-600" />
                        <Badge className="bg-amber-600">Premium: {item.premium}</Badge>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* All Features */}
            <div>
              <div className="mb-3 flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500" />
                Complete Premium Feature Set
              </div>
              <div className="grid md:grid-cols-3 gap-3">
                {premiumFeatures.map((item, idx) => (
                  <Card key={idx} className="p-3">
                    <div className="flex items-start gap-2">
                      <item.icon className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="text-sm mb-1">{item.title}</div>
                        <p className="text-xs text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Comparison Table */}
            <div>
              <div className="mb-3 flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-primary" />
                Free vs Premium Comparison
              </div>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted">
                    <tr>
                      <th className="text-left p-3">Feature</th>
                      <th className="text-center p-3">Free</th>
                      <th className="text-center p-3 bg-amber-50">
                        <div className="flex items-center justify-center gap-1">
                          <Crown className="w-4 h-4 text-amber-600" />
                          Premium
                        </div>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonFeatures.map((item, idx) => (
                      <tr key={idx} className="border-t">
                        <td className="p-3">{item.feature}</td>
                        <td className="p-3 text-center text-muted-foreground">{item.free}</td>
                        <td className="p-3 text-center bg-amber-50">
                          <div className="flex items-center justify-center gap-2">
                            <Check className="w-4 h-4 text-green-600" />
                            <span className="text-amber-900">{item.premium}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* CTA */}
            <Card className="p-6 bg-gradient-to-r from-amber-500 to-yellow-500 text-white border-0">
              <div className="text-center space-y-4">
                <div>
                  <div className="text-2xl mb-2">$19.99 per month</div>
                  <p className="text-amber-100">
                    Less than $1 per day to protect your family and fight for your children
                  </p>
                </div>
                <div className="flex items-center justify-center gap-4">
                  <Button 
                    size="lg" 
                    className="bg-white text-amber-600 hover:bg-amber-50"
                    onClick={() => handleUpgrade('premium')}
                  >
                    <Crown className="w-5 h-5 mr-2" />
                    Upgrade to Premium Now
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline" 
                    className="bg-transparent border-white text-white hover:bg-white/20"
                    onClick={() => {
                      setShowModal(false);
                      if (onClose) onClose();
                    }}
                  >
                    Maybe Later
                  </Button>
                </div>
                <p className="text-xs text-amber-100">
                  🔒 Secure payment processing • Cancel anytime • 30-day money-back guarantee
                </p>
              </div>
            </Card>

            {/* Trust Signals */}
            <div className="text-center space-y-2">
              <p className="text-sm text-muted-foreground">
                ⭐⭐⭐⭐⭐ Trusted by thousands of parents fighting CPS
              </p>
              <p className="text-xs text-muted-foreground">
                "This app helped me identify 12 violations and reunify with my kids in 4 months" - Sarah M., Texas
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Inline Upgrade Card (when not in modal) */}
      {!isOpen && !showModal && (
        <Card className="p-6 bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 border-2 border-amber-200">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="mb-2 flex items-center gap-2">
                <Crown className="w-6 h-6 text-amber-600" />
                <span className="text-xl text-amber-900">Unlock Premium Features</span>
                <Badge className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white">
                  $19.99/month
                </Badge>
              </div>
              <p className="text-sm text-amber-800 mb-4">
                Get unlimited AI analysis, professional document generation, encrypted storage, 
                and complete legal powerhouse toolkit. Fight CPS with every weapon available.
              </p>
              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-600 mt-0.5" />
                  <div className="text-sm text-amber-900">
                    <div className="font-medium">Unlimited AI Analysis</div>
                    <div className="text-xs text-amber-700">Find every violation</div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-600 mt-0.5" />
                  <div className="text-sm text-amber-900">
                    <div className="font-medium">Auto-Filled Documents</div>
                    <div className="text-xs text-amber-700">Court-ready in minutes</div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-600 mt-0.5" />
                  <div className="text-sm text-amber-900">
                    <div className="font-medium">Professional Brief</div>
                    <div className="text-xs text-amber-700">Attorney-ready case summary</div>
                  </div>
                </div>
              </div>
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700"
                onClick={() => setShowModal(true)}
              >
                <Crown className="w-5 h-5 mr-2" />
                View All Premium Features
              </Button>
            </div>
          </div>
        </Card>
      )}
    </>
  );
}

// Premium Feature Badge Component
export function PremiumBadge({ feature }: { feature?: string }) {
  const [showUpgrade, setShowUpgrade] = useState(false);
  const { tier } = useSubscription();

  if (tier === 'premium') return null;

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="gap-2 border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-700"
        onClick={() => setShowUpgrade(true)}
      >
        <Lock className="w-3 h-3" />
        <span className="text-xs">Premium</span>
      </Button>
      <PremiumUpgrade 
        isOpen={showUpgrade} 
        onClose={() => setShowUpgrade(false)} 
        feature={feature}
      />
    </>
  );
}

// Premium Lock Component (for locked features)
export function PremiumLock({ feature, description }: { feature: string; description?: string }) {
  const [showUpgrade, setShowUpgrade] = useState(false);

  return (
    <>
      <Card className="p-8 text-center bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-200">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <div>
            <div className="text-xl mb-2 text-amber-900">{feature}</div>
            {description && (
              <p className="text-sm text-amber-700 mb-4">{description}</p>
            )}
          </div>
          <Button 
            size="lg"
            className="bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700"
            onClick={() => setShowUpgrade(true)}
          >
            <Crown className="w-5 h-5 mr-2" />
            Unlock Premium - $19.99/month
          </Button>
          <p className="text-xs text-muted-foreground">
            Cancel anytime • 30-day money-back guarantee
          </p>
        </div>
      </Card>
      <PremiumUpgrade 
        isOpen={showUpgrade} 
        onClose={() => setShowUpgrade(false)} 
        feature={feature}
      />
    </>
  );
}