import { createContext, useContext, useState, ReactNode } from 'react';

type SubscriptionTier = 'free' | 'essential' | 'professional' | 'attorney' | 'enterprise';

interface SubscriptionContextType {
  tier: SubscriptionTier;
  setTier: (tier: SubscriptionTier) => void;
  isEnterprise: boolean;
  isAttorney: boolean;
  isProfessional: boolean;
  isEssential: boolean;
  isFree: boolean;
  checkFeatureAccess: (feature: string) => boolean;
  getDocumentLimit: () => number | 'unlimited';
  getViolationLimit: () => number | 'unlimited';
  canSeeFullViolationDetails: () => boolean;
  getAICreditsLimit: () => number;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export function SubscriptionProvider({ children }: { children: ReactNode }) {
  // DEV MODE: Set to 'attorney' or 'enterprise' to test premium features
  const [tier, setTier] = useState<SubscriptionTier>('attorney');

  const checkFeatureAccess = (feature: string): boolean => {
    const featureMap: Record<string, SubscriptionTier[]> = {
      'community_forum': ['essential', 'professional', 'attorney', 'enterprise'],
      'virtual_case_binder': ['professional', 'attorney', 'enterprise'],
      'full_reports': ['professional', 'attorney', 'enterprise'],
      'ai_paralegal': ['attorney', 'enterprise'],
      'multi_client': ['attorney', 'enterprise'],
      'multi_state_law': ['attorney', 'enterprise'],
      'enhanced_ai': ['professional', 'attorney', 'enterprise'],
      'case_law_access': ['professional', 'attorney', 'enterprise'],
      'podcast': ['professional', 'attorney', 'enterprise'],
      'basic_ai': ['essential', 'professional', 'attorney', 'enterprise'],
    };

    return featureMap[feature]?.includes(tier) ?? false;
  };

  const getDocumentLimit = (): number | 'unlimited' => {
    switch (tier) {
      case 'free':
        return 1;
      case 'essential':
        return 25;
      default:
        return 'unlimited';
    }
  };

  const getViolationLimit = (): number | 'unlimited' => {
    if (tier === 'free') return 5; // Free users can check up to 5 violations
    return 'unlimited';
  };

  const canSeeFullViolationDetails = (): boolean => {
    return tier !== 'free';
  };

  const getAICreditsLimit = (): number => {
    switch (tier) {
      case 'free':
        return 0;
      case 'essential':
        return 25;
      case 'professional':
        return 100;
      case 'attorney':
        return 500;
      case 'enterprise':
        return 2000;
      default:
        return 0;
    }
  };

  return (
    <SubscriptionContext.Provider 
      value={{ 
        tier, 
        setTier,
        isEnterprise: tier === 'enterprise',
        isAttorney: tier === 'attorney' || tier === 'enterprise',
        isProfessional: tier === 'professional' || tier === 'attorney' || tier === 'enterprise',
        isEssential: tier === 'essential' || tier === 'professional' || tier === 'attorney' || tier === 'enterprise',
        isFree: tier === 'free',
        checkFeatureAccess,
        getDocumentLimit,
        getViolationLimit,
        canSeeFullViolationDetails,
        getAICreditsLimit,
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
}