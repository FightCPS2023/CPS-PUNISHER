import { Hono } from "npm:hono";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// ===== ADVOCATES & ATTORNEYS =====

// GET all advocates/attorneys with optional filters
app.get("/advocates", async (c) => {
  try {
    const state = c.req.query("state");
    const type = c.req.query("type"); // 'advocate' or 'attorney'
    const availability = c.req.query("availability");

    // Get all advocates from KV store
    const allAdvocates = await kv.getByPrefix("advocate:");
    
    let filtered = allAdvocates;

    // Apply filters
    if (state) {
      filtered = filtered.filter((a: any) => a.state === state);
    }
    if (type) {
      filtered = filtered.filter((a: any) => a.type === type);
    }
    if (availability) {
      filtered = filtered.filter((a: any) => a.availability === availability);
    }

    // Sort by rating and verification status
    filtered.sort((a: any, b: any) => {
      if (a.verified !== b.verified) return b.verified ? 1 : -1;
      return (b.rating || 0) - (a.rating || 0);
    });

    return c.json({ data: filtered });
  } catch (error: any) {
    console.error("Error fetching advocates:", error);
    return c.json({ error: error.message }, 500);
  }
});

// GET single advocate by ID
app.get("/advocates/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const advocate = await kv.get(`advocate:${id}`);

    if (!advocate) {
      return c.json({ error: "Advocate not found" }, 404);
    }

    return c.json({ data: advocate });
  } catch (error: any) {
    console.error("Error fetching advocate:", error);
    return c.json({ error: error.message }, 500);
  }
});

// POST new advocate (signup)
app.post("/advocates", async (c) => {
  try {
    const data = await c.req.json();

    // Validate required fields
    if (!data.name || !data.email || !data.phone || !data.state || !data.type) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Generate unique ID
    const id = crypto.randomUUID();
    const timestamp = new Date().toISOString();

    const advocate = {
      id,
      ...data,
      verified: false, // Admin must verify
      rating: 0,
      reviewCount: 0,
      joinedDate: timestamp,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    // Save to KV store
    await kv.set(`advocate:${id}`, advocate);

    // Also save to pending approvals
    await kv.set(`advocate_pending:${id}`, advocate);

    console.log(`New advocate signup: ${data.name} (${data.email})`);

    return c.json({ 
      data: advocate,
      message: "Application submitted successfully! We'll review and activate your profile within 24-48 hours."
    }, 201);
  } catch (error: any) {
    console.error("Error creating advocate:", error);
    return c.json({ error: error.message }, 500);
  }
});

// PUT update advocate
app.put("/advocates/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const updates = await c.req.json();

    const existing = await kv.get(`advocate:${id}`);
    if (!existing) {
      return c.json({ error: "Advocate not found" }, 404);
    }

    const updated = {
      ...existing,
      ...updates,
      id, // Prevent ID change
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`advocate:${id}`, updated);

    return c.json({ data: updated });
  } catch (error: any) {
    console.error("Error updating advocate:", error);
    return c.json({ error: error.message }, 500);
  }
});

// DELETE advocate
app.delete("/advocates/:id", async (c) => {
  try {
    const id = c.req.param("id");
    
    const existing = await kv.get(`advocate:${id}`);
    if (!existing) {
      return c.json({ error: "Advocate not found" }, 404);
    }

    await kv.del(`advocate:${id}`);

    return c.json({ message: "Advocate deleted successfully" });
  } catch (error: any) {
    console.error("Error deleting advocate:", error);
    return c.json({ error: error.message }, 500);
  }
});

// ===== RESOURCE LINKS =====

// GET all resource links with optional filters
app.get("/resources", async (c) => {
  try {
    const category = c.req.query("category");
    const type = c.req.query("type");
    const state = c.req.query("state");

    const allResources = await kv.getByPrefix("resource:");
    
    let filtered = allResources;

    if (category) {
      filtered = filtered.filter((r: any) => r.category === category);
    }
    if (type) {
      filtered = filtered.filter((r: any) => r.type === type);
    }
    if (state) {
      filtered = filtered.filter((r: any) => r.state === state);
    }

    // Sort by upvotes (highest first)
    filtered.sort((a: any, b: any) => {
      if (a.verified !== b.verified) return b.verified ? 1 : -1;
      return (b.upvotes || 0) - (a.upvotes || 0);
    });

    return c.json({ data: filtered });
  } catch (error: any) {
    console.error("Error fetching resources:", error);
    return c.json({ error: error.message }, 500);
  }
});

// GET single resource by ID
app.get("/resources/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const resource = await kv.get(`resource:${id}`);

    if (!resource) {
      return c.json({ error: "Resource not found" }, 404);
    }

    return c.json({ data: resource });
  } catch (error: any) {
    console.error("Error fetching resource:", error);
    return c.json({ error: error.message }, 500);
  }
});

// POST new resource link
app.post("/resources", async (c) => {
  try {
    const data = await c.req.json();

    // Validate required fields
    if (!data.title || !data.url || !data.description || !data.category || !data.type) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    const id = crypto.randomUUID();
    const timestamp = new Date().toISOString();

    const resource = {
      id,
      ...data,
      upvotes: 0,
      verified: false, // Admin must verify
      submittedBy: data.submittedBy || "Anonymous",
      dateAdded: timestamp,
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    await kv.set(`resource:${id}`, resource);
    
    // Also save to pending approvals
    await kv.set(`resource_pending:${id}`, resource);

    console.log(`New resource submitted: ${data.title} (${data.url})`);

    return c.json({ 
      data: resource,
      message: "Resource submitted successfully! It will be reviewed and added within 24 hours."
    }, 201);
  } catch (error: any) {
    console.error("Error creating resource:", error);
    return c.json({ error: error.message }, 500);
  }
});

// POST upvote a resource
app.post("/resources/:id/upvote", async (c) => {
  try {
    const id = c.req.param("id");
    const { userId } = await c.req.json();

    // Check if user already upvoted
    const upvoteKey = `resource_upvote:${id}:${userId}`;
    const alreadyUpvoted = await kv.get(upvoteKey);

    if (alreadyUpvoted) {
      return c.json({ error: "You've already upvoted this resource" }, 400);
    }

    // Get resource
    const resource = await kv.get(`resource:${id}`);
    if (!resource) {
      return c.json({ error: "Resource not found" }, 404);
    }

    // Increment upvotes
    const updated = {
      ...resource,
      upvotes: (resource.upvotes || 0) + 1,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`resource:${id}`, updated);
    
    // Record the upvote
    await kv.set(upvoteKey, { userId, timestamp: new Date().toISOString() });

    return c.json({ data: updated });
  } catch (error: any) {
    console.error("Error upvoting resource:", error);
    return c.json({ error: error.message }, 500);
  }
});

// PUT update resource
app.put("/resources/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const updates = await c.req.json();

    const existing = await kv.get(`resource:${id}`);
    if (!existing) {
      return c.json({ error: "Resource not found" }, 404);
    }

    const updated = {
      ...existing,
      ...updates,
      id, // Prevent ID change
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`resource:${id}`, updated);

    return c.json({ data: updated });
  } catch (error: any) {
    console.error("Error updating resource:", error);
    return c.json({ error: error.message }, 500);
  }
});

// DELETE resource
app.delete("/resources/:id", async (c) => {
  try {
    const id = c.req.param("id");
    
    const existing = await kv.get(`resource:${id}`);
    if (!existing) {
      return c.json({ error: "Resource not found" }, 404);
    }

    await kv.del(`resource:${id}`);

    return c.json({ message: "Resource deleted successfully" });
  } catch (error: any) {
    console.error("Error deleting resource:", error);
    return c.json({ error: error.message }, 500);
  }
});

// ===== ADMIN ROUTES =====

// GET pending advocates for approval
app.get("/admin/advocates/pending", async (c) => {
  try {
    const pending = await kv.getByPrefix("advocate_pending:");
    return c.json({ data: pending });
  } catch (error: any) {
    console.error("Error fetching pending advocates:", error);
    return c.json({ error: error.message }, 500);
  }
});

// POST approve advocate
app.post("/admin/advocates/:id/approve", async (c) => {
  try {
    const id = c.req.param("id");
    
    const pending = await kv.get(`advocate_pending:${id}`);
    if (!pending) {
      return c.json({ error: "Pending advocate not found" }, 404);
    }

    // Mark as verified and move to active
    const approved = {
      ...pending,
      verified: true,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`advocate:${id}`, approved);
    await kv.del(`advocate_pending:${id}`);

    console.log(`Advocate approved: ${approved.name}`);

    return c.json({ data: approved, message: "Advocate approved successfully" });
  } catch (error: any) {
    console.error("Error approving advocate:", error);
    return c.json({ error: error.message }, 500);
  }
});

// GET pending resources for approval
app.get("/admin/resources/pending", async (c) => {
  try {
    const pending = await kv.getByPrefix("resource_pending:");
    return c.json({ data: pending });
  } catch (error: any) {
    console.error("Error fetching pending resources:", error);
    return c.json({ error: error.message }, 500);
  }
});

// POST approve resource
app.post("/admin/resources/:id/approve", async (c) => {
  try {
    const id = c.req.param("id");
    
    const pending = await kv.get(`resource_pending:${id}`);
    if (!pending) {
      return c.json({ error: "Pending resource not found" }, 404);
    }

    // Mark as verified and move to active
    const approved = {
      ...pending,
      verified: true,
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`resource:${id}`, approved);
    await kv.del(`resource_pending:${id}`);

    console.log(`Resource approved: ${approved.title}`);

    return c.json({ data: approved, message: "Resource approved successfully" });
  } catch (error: any) {
    console.error("Error approving resource:", error);
    return c.json({ error: error.message }, 500);
  }
});

// ===== SEED DATA (For initial launch) =====

app.post("/admin/seed-data", async (c) => {
  try {
    // Check if already seeded
    const existing = await kv.getByPrefix("advocate:");
    if (existing.length > 0) {
      return c.json({ message: "Data already seeded" });
    }

    // Seed sample advocates
    const sampleAdvocates = [
      {
        id: crypto.randomUUID(),
        type: 'attorney',
        name: 'Sarah Johnson',
        credentials: 'J.D., Family Law Specialist',
        email: 'sarah.johnson@familylaw.com',
        phone: '(555) 123-4567',
        website: 'https://sarahjohnsonlaw.com',
        state: 'Texas',
        county: 'Harris County',
        cities: ['Houston', 'Sugar Land', 'Pearland'],
        specializations: ['CPS Defense', 'Termination Cases', 'Reunification', 'Appeals'],
        about: 'Experienced family law attorney with 15+ years defending parents against CPS. Successfully reunified over 200 families. Board certified in family law.',
        yearsExperience: 15,
        barNumber: 'TX-12345678',
        rates: '$250-350/hr, Payment plans available',
        availability: 'available',
        socialMedia: {
          facebook: 'https://facebook.com/sarahjohnsonlaw',
          linkedin: 'https://linkedin.com/in/sarahjohnson',
        },
        rating: 4.9,
        reviewCount: 47,
        verified: true,
        joinedDate: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: crypto.randomUUID(),
        type: 'advocate',
        name: 'Michael Rodriguez',
        credentials: 'Certified Parent Advocate',
        email: 'michael@cpsadvocacy.org',
        phone: '(555) 234-5678',
        website: 'https://cpsadvocacy.org',
        state: 'Texas',
        county: 'Dallas County',
        cities: ['Dallas', 'Plano', 'Richardson'],
        specializations: ['Court Navigation', 'Service Plan Completion', 'Visitation Support'],
        about: 'Former CPS parent who successfully fought for reunification. Now helping others navigate the system. Free services available for low-income families.',
        yearsExperience: 8,
        rates: 'Free - $50/session',
        availability: 'available',
        socialMedia: {
          facebook: 'https://facebook.com/cpsadvocacy',
          instagram: 'https://instagram.com/cpsadvocate',
        },
        rating: 4.8,
        reviewCount: 93,
        verified: true,
        joinedDate: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: crypto.randomUUID(),
        type: 'attorney',
        name: 'Jennifer Martinez',
        credentials: 'J.D., Board Certified Family Law',
        email: 'jmartinez@martinezcpslaw.com',
        phone: '(555) 345-6789',
        website: 'https://martinezcpslaw.com',
        state: 'California',
        county: 'Los Angeles County',
        cities: ['Los Angeles', 'Long Beach', 'Pasadena'],
        specializations: ['§1983 Civil Rights', 'Constitutional Claims', 'CPS Defense'],
        about: 'Aggressive CPS defense attorney specializing in federal civil rights lawsuits. Won multiple six-figure verdicts against CPS for constitutional violations.',
        yearsExperience: 12,
        barNumber: 'CA-98765432',
        rates: '$300-400/hr, Contingency available for §1983',
        availability: 'limited',
        socialMedia: {
          linkedin: 'https://linkedin.com/in/jennifermartinez',
          youtube: 'https://youtube.com/martinezcpslaw',
        },
        rating: 5.0,
        reviewCount: 28,
        verified: true,
        joinedDate: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];

    // Save advocates
    for (const advocate of sampleAdvocates) {
      await kv.set(`advocate:${advocate.id}`, advocate);
    }

    // Seed sample resources
    const sampleResources = [
      {
        id: crypto.randomUUID(),
        title: 'National Coalition for Child Protection Reform',
        url: 'https://www.nccpr.org',
        description: 'Leading advocacy organization fighting for family preservation and CPS reform. Extensive research, news, and resources on CPS system abuse.',
        category: 'advocacy',
        type: 'organization',
        upvotes: 247,
        submittedBy: 'Admin',
        verified: true,
        tags: ['advocacy', 'research', 'national', 'reform'],
        dateAdded: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: crypto.randomUUID(),
        title: 'Family Defense Center',
        url: 'https://familydefensecenter.org',
        description: 'Provides free legal representation to low-income parents in CPS cases. Advocacy, training, and policy reform work.',
        category: 'legal-help',
        type: 'organization',
        state: 'Illinois',
        upvotes: 189,
        submittedBy: 'Admin',
        verified: true,
        tags: ['legal-aid', 'free', 'illinois', 'representation'],
        dateAdded: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: crypto.randomUUID(),
        title: 'Fourth Amendment Center - CPS Rights',
        url: 'https://fourthamendment.com/cps',
        description: 'Comprehensive guide to Fourth Amendment rights during CPS investigations. Know your rights when CPS comes to your door.',
        category: 'education',
        type: 'legal-resource',
        upvotes: 312,
        submittedBy: 'Admin',
        verified: true,
        tags: ['constitutional-rights', '4th-amendment', 'guide'],
        dateAdded: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: crypto.randomUUID(),
        title: 'Parents Against CPS Corruption (Facebook Group)',
        url: 'https://facebook.com/groups/cpscorruption',
        description: '50,000+ member support group for parents fighting CPS. Share experiences, get advice, find local resources.',
        category: 'support',
        type: 'support-group',
        upvotes: 445,
        submittedBy: 'User123',
        verified: false,
        tags: ['support', 'community', 'facebook', 'national'],
        dateAdded: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: crypto.randomUUID(),
        title: 'CPS Defense Attorney YouTube Channel',
        url: 'https://youtube.com/cpsdefense',
        description: 'Weekly videos on CPS defense strategies, constitutional rights, and winning case examples. Free legal education.',
        category: 'education',
        type: 'video',
        upvotes: 278,
        submittedBy: 'AttorneyMike',
        verified: true,
        tags: ['video', 'education', 'strategies', 'free'],
        dateAdded: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: crypto.randomUUID(),
        title: 'Template Library - CPS Court Documents',
        url: 'https://cpstemplates.org',
        description: 'Free downloadable templates for motions, petitions, discovery requests, and appeals. Professional legal formatting.',
        category: 'legal-help',
        type: 'document',
        upvotes: 567,
        submittedBy: 'Admin',
        verified: true,
        tags: ['templates', 'free', 'documents', 'motions'],
        dateAdded: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];

    // Save resources
    for (const resource of sampleResources) {
      await kv.set(`resource:${resource.id}`, resource);
    }

    console.log(`Seeded ${sampleAdvocates.length} advocates and ${sampleResources.length} resources`);

    return c.json({ 
      message: "Data seeded successfully",
      advocates: sampleAdvocates.length,
      resources: sampleResources.length
    });
  } catch (error: any) {
    console.error("Error seeding data:", error);
    return c.json({ error: error.message }, 500);
  }
});

export default app;
