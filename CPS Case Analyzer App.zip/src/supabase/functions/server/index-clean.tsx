import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

app.use('*', logger(console.log));

app.use("/*", cors({
  origin: "*",
  allowHeaders: ["Content-Type", "Authorization"],
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  exposeHeaders: ["Content-Length"],
  maxAge: 600,
}));

// SIGNUP
app.post("/make-server-a24eaa40/auth/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password || !name) {
      return c.json({ error: 'Email, password, and name are required' }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      email_confirm: true
    });

    if (error) {
      return c.json({ error: error.message }, 400);
    }

    return c.json({ 
      success: true,
      userId: data.user.id,
      message: 'Account created successfully'
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// LOGIN
app.post("/make-server-a24eaa40/auth/login", async (c) => {
  try {
    const { email, password } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400);
    }

    const anonSupabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    );

    const { data, error } = await anonSupabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return c.json({ error: error.message }, 401);
    }

    return c.json({
      success: true,
      accessToken: data.session.access_token,
      userId: data.user.id,
      user: {
        email: data.user.email,
        name: data.user.user_metadata?.name
      }
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// AUTH MIDDLEWARE
const requireAuth = async (c: any, next: any) => {
  const authHeader = c.req.header('Authorization');
  const accessToken = authHeader?.split(' ')[1];

  if (!accessToken) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  const { data: { user }, error } = await supabase.auth.getUser(accessToken);

  if (error || !user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  c.set('userId', user.id);
  await next();
};

// SAVE DATA
app.post("/make-server-a24eaa40/data/save", requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const body = await c.req.json();

    await kv.set(`user_data:${userId}`, {
      ...body,
      lastSaved: new Date().toISOString()
    });

    return c.json({ 
      success: true,
      message: 'Data saved successfully' 
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// LOAD DATA
app.get("/make-server-a24eaa40/data/load", requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const data = await kv.get(`user_data:${userId}`);

    if (!data) {
      return c.json({
        success: true,
        data: {
          documents: [],
          timelineEvents: [],
          caseDetails: {
            caseNumber: "",
            county: "",
            dateOpened: "",
            caseworker: "",
            attorney: "",
          },
          violations: {}
        }
      });
    }

    return c.json({
      success: true,
      data
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// HEALTH CHECK
app.get("/make-server-a24eaa40/health", (c) => {
  return c.json({ status: "ok" });
});

Deno.serve(app.fetch);
