import { adminApi } from './communityApi';

/**
 * Initialize community data on first app launch
 * Seeds sample advocates and resource links
 */
export async function initializeCommunityData(): Promise<boolean> {
  try {
    // Check if already initialized
    const hasInit = localStorage.getItem('cps_community_initialized');
    if (hasInit) {
      console.log('Community data already initialized');
      return true;
    }

    console.log('Initializing community data...');
    
    // Call the seed endpoint
    const result = await adminApi.seedData();
    
    console.log('Community data seeded:', result);
    
    // Mark as initialized
    localStorage.setItem('cps_community_initialized', 'true');
    
    return true;
  } catch (error: any) {
    console.error('Error initializing community data:', error);
    
    // If error is "already seeded", mark as initialized anyway
    if (error.message && error.message.includes('already seeded')) {
      localStorage.setItem('cps_community_initialized', 'true');
      return true;
    }
    
    return false;
  }
}
